﻿using AutoMapper;
using ImageUploas.Dtos;
using ImageUploas.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ImageUploas.Controllers
{
	public class StudentControlller : Controller
	{
		public readonly IMapper _mapper;
		StudentContext _studentContext;
<<<<<<< HEAD
		private readonly IWebHostEnvironment _env;
		public StudentControlller(IMapper mapper, StudentContext studentContext, IWebHostEnvironment env)
		{
			_mapper = mapper;
			_studentContext = studentContext;
			_env = env;
=======

		public StudentControlller(IMapper mapper, StudentContext studentContext)
		{
			_mapper = mapper;
			_studentContext = studentContext;
>>>>>>> 0747671329b8e402ffad907c36251d4fb6fcd6f2
		}

		public IActionResult Index()
		{
			var students = _studentContext.Students.ToList(); // Or fetch with async if needed
			return View(students);
		}
		[HttpGet]
		public IActionResult AddStudent()
		{
			return View();

		}
		[HttpPost]
		public async  Task<IActionResult> AddStudent(StudentDTos student)
		{

			if (student.Image != null && student.Image.Length > 0)
			{
<<<<<<< HEAD
				// Generate unique file name
				var fileName = $"{Guid.NewGuid()}{Path.GetExtension(student.Image.FileName)}";

				// Get full path to wwwroot/images
				var imagesPath = Path.Combine(_env.WebRootPath, "images");

				// Ensure directory exists
				if (!Directory.Exists(imagesPath))
					Directory.CreateDirectory(imagesPath);

				// Combine full file path
				var filePath = Path.Combine(imagesPath, fileName);

				// Save the file
=======
				var filePath = Path.Combine("wwwroot/images", student.Image.FileName);
>>>>>>> 0747671329b8e402ffad907c36251d4fb6fcd6f2
				using (var stream = new FileStream(filePath, FileMode.Create))
				{
					await student.Image.CopyToAsync(stream);
				}
<<<<<<< HEAD

				// Save relative path to DB
				var std=_mapper.Map<Student>(student);
				std.Image= $"images/{fileName}";
				_studentContext.Students.Add(std);
				await _studentContext.SaveChangesAsync();
				return RedirectToAction("Index");
			}
		return View();	

			
		}

			
		}

	}

=======
				var st = _mapper.Map<Student>(student);
				st.Image = filePath;
				_studentContext.Students.AddAsync(st);
				_studentContext.SaveChanges();

			}


			return View(student);	
		}

	}
}
>>>>>>> 0747671329b8e402ffad907c36251d4fb6fcd6f2
