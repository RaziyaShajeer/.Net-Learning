﻿namespace MVCSample.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public string emaiId { get; set; }

        public string Password {  get; set; }

    }
}
