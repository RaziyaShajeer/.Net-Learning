﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic;

namespace MVCSample.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public String getname()
        {
            return "My name is Fara";
        }
    }
}